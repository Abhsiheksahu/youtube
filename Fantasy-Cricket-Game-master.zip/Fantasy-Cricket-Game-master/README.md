# Fantasy-Cricket-Game
This is a fantasy Cricket Game. It was built as part of Internshala Programming with Python Training Contest and won the first prize in the contest. The game allows you to create a virtual team of cricket players and calculate their score points on how the players perform in different matches. For simplicity, only one match has been listed. You can create different teams of players and find their score in the match. The application is developed with Python programming language and SQLite database. The game UI was designed with QT Designer.

Please use this only as a guideline for your project. You may take inspiration from this project but PLEASE DON'T UPLOAD THE SAME FOR YOUR FINAL PROJECT IN INTERNSHALA PYTHON TRAININGS. YOUR FINAL PROJECT MUST BE ENTIRELY YOUR OWN ORIGINAL WORK.

![Fantasy Cricket Game](/IMAGES/logo.png)

GitHub repository for this project: https://github.com/jincy-p-janardhanan/Fantasy-Cricket-Game

Find me on GitHub: https://github.com/jincy-p-janardhanan

Find me on LinkedIn: https://www.linkedin.com/in/jincy-p-janardhanan/
